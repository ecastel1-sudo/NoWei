"""submission.py -- robust deepseek-equivalent placement + stateful transit
reduction.

This rewrite keeps the action space and PAR-quality of deepseek and changes
exactly ONE thing the deepseek baseline lacks: STATE.

Algorithm:
  1. Compute the same replicate-then-pack placement deepseek would.
     - Same water-filling replication (load / replica_count argmax).
     - Same LPT bin-packing onto devices.
     Run in numpy so per-call cost is below the simulator's iter budget.
  2. ANCHOR the proposed placement to the current one by permuting device
     rows. PAR is invariant under this permutation (PAR depends only on the
     per-device load multiset), so the placement quality is unchanged. The
     actual physical-slot diff (the transit term in the score) drops a lot
     because most devices keep the same expert sets they already had.
  3. SKIP any layer whose anchored proposal equals the current placement.
     The simulator already pays a small per-layer transit even for "no real
     change"; explicitly dropping those layers from the priority list saves
     it.

What we explicitly do NOT do (lessons from v1):
  - No top-K layer cap: every layer is proposed, every layer gets a fair
    chance to be re-balanced. v1 only proposed K=2..8 layers per call which
    left cold layers on the simulator's poor default placement forever.
  - No EWMA / no clip: deepseek's window sum is what it is graded against;
    smoothing changed the input distribution and tripped us up on long
    multi-trace runs where each per-case state was short.
  - No cost gate / safety multiplier: the simulator already prices a slot
    move at ~98us vs a PAR point at ~60s; if deepseek's pack gives us a
    different placement, the win is worth the move. v1's SAFETY=20 was
    blocking genuinely good redeploys.

API contract (matches dynamic_lb_simulator.py exactly):
  rebalance(hotness, n_device, n_red_expert)
    hotness: np.ndarray with shape (window, n_layers, n_experts)
    returns: (change, layers_priority, deployment, _aux)
      change          - bool, True iff at least one layer is being redeployed
      layers_priority - np.int64 array of the layer indices the simulator
                        should redeploy, in the order it should apply them
      deployment      - np.int64 array (n_layers, n_device, exp_per_dev).
                        Layers not in layers_priority MUST still carry valid
                        data; we always return our latest cur_deploy mirror.
      _aux            - placeholder, always None
"""

from __future__ import annotations

import numpy as np

# ---------- module state ----------------------------------------------------
# Mirror of what we believe the simulator currently has deployed. The simulator
# adapter at eplb_algorithms/__init__.py calls _reset() at the start of each
# run, so cross-run state leakage is impossible.
_STATE: dict = {"cur_deploy": None}


def _reset() -> None:
    """Clear module state. Called by the adapter on every fresh run."""
    _STATE["cur_deploy"] = None


# ---------- deepseek-equivalent placement (numpy) ---------------------------
def _init_deploy(n_layers: int, n_device: int, n_experts: int,
                 n_phys: int) -> np.ndarray:
    """Default placement matching dynamic_lb_simulator.init_deploy_table when
    n_red_expert > 0: each device's last slot duplicates the previous one.
    Used only the very first time rebalance() is called for a given shape,
    to seed the cur_deploy mirror so anchoring has something to anchor to.
    """
    exp_per_dev = n_phys // n_device
    base_slots = exp_per_dev - 1
    dep = np.zeros((n_layers, n_device, exp_per_dev), dtype=np.int64)
    for d in range(n_device):
        for s in range(base_slots):
            dep[:, d, s] = (d * base_slots + s) % n_experts
        dep[:, d, -1] = dep[:, d, -2]
    return dep


def _replicate_experts(weight_1d: np.ndarray, n_phys: int):
    """Water-filling replication, byte-for-byte equivalent to deepseek's
    `replicate_experts`: each new physical slot is given to the logical
    expert with the largest `load / replica_count`.

    Returns:
        phy2log: (n_phys,) np.int64, logical id held by each physical slot
        logcnt:  (n_log,)  np.int64, replica count per logical expert
    """
    n_log = weight_1d.shape[0]
    phy2log = np.empty(n_phys, dtype=np.int64)
    phy2log[:n_log] = np.arange(n_log, dtype=np.int64)
    logcnt = np.ones(n_log, dtype=np.int64)
    for slot in range(n_log, n_phys):
        pick = int(np.argmax(weight_1d / logcnt))
        phy2log[slot] = pick
        logcnt[pick] += 1
    return phy2log, logcnt


def _balanced_pack_lpt(weights_1d: np.ndarray, n_packs: int):
    """LPT (longest-processing-time first) bin packing with equal-count packs.
    Equivalent to deepseek's `balanced_packing` for num_groups == n_packs.
    Each pack ends up with the same number of items; loads are as balanced
    as the greedy lets them be.

    Returns:
        pack_index   : (n,) which pack each item went into
        rank_in_pack : (n,) the item's index within its pack
    """
    n = weights_1d.shape[0]
    items_per_pack = n // n_packs
    order = np.argsort(-weights_1d)
    pack_load = np.zeros(n_packs, dtype=np.float64)
    pack_count = np.zeros(n_packs, dtype=np.int64)
    pack_index = np.empty(n, dtype=np.int64)
    rank_in_pack = np.empty(n, dtype=np.int64)
    for it in order:
        # Lightest pack that still has room.
        masked = np.where(pack_count < items_per_pack, pack_load, np.inf)
        choice = int(np.argmin(masked))
        pack_index[it] = choice
        rank_in_pack[it] = pack_count[choice]
        pack_load[choice] += weights_1d[it]
        pack_count[choice] += 1
    return pack_index, rank_in_pack


def _propose_layer(weight_1d: np.ndarray, n_device: int,
                   n_phys: int) -> np.ndarray:
    """Replicate-then-pack -> placement of shape (n_device, exp_per_dev).
    Same action and (numerically) same per-device load multiset as deepseek
    in non-hierarchical mode."""
    phy2log, logcnt = _replicate_experts(weight_1d, n_phys)
    tokens_per_phy = weight_1d[phy2log] / logcnt[phy2log]
    pack_idx, rank = _balanced_pack_lpt(tokens_per_phy, n_device)
    exp_per_dev = n_phys // n_device
    deploy = np.empty((n_device, exp_per_dev), dtype=np.int64)
    deploy[pack_idx, rank] = phy2log
    return deploy


# ---------- the one trick deepseek does not do ------------------------------
def _anchor_to_prev(new_deploy: np.ndarray, prev_deploy: np.ndarray,
                    n_experts: int) -> np.ndarray:
    """Permute the device rows of `new_deploy` to maximise overlap with
    `prev_deploy`. PAR is invariant under this permutation (it depends only
    on the per-device load multisets); the physical transit count drops
    because most slots stay identical.

    Implementation: build the (n_device, n_device) overlap matrix using BLAS,
    then greedy assignment processing strongest available match first.
    O(n_device^2 * n_experts) for the matmul, O(n_device^2) for the match.
    """
    n_dev = new_deploy.shape[0]
    rows = np.repeat(np.arange(n_dev), new_deploy.shape[1])
    new_oh = np.zeros((n_dev, n_experts), dtype=np.float32)
    prev_oh = np.zeros((n_dev, n_experts), dtype=np.float32)
    new_oh[rows, new_deploy.reshape(-1)] = 1.0
    prev_oh[rows, prev_deploy.reshape(-1)] = 1.0
    overlap = new_oh @ prev_oh.T  # (n_dev, n_dev), BLAS

    used = np.zeros(n_dev, dtype=bool)
    mapping = np.empty(n_dev, dtype=np.int64)
    # Process devices whose best-available match is strongest first; that
    # locks in dominant overlaps before they get stolen by greedy tie-breaks.
    process_order = np.argsort(-overlap.max(axis=1))
    NEG = np.float32(-1.0)
    for i in process_order:
        scores = overlap[i].copy()
        scores[used] = NEG
        j = int(np.argmax(scores))
        mapping[i] = j
        used[j] = True

    out = np.empty_like(new_deploy)
    out[mapping] = new_deploy
    return out


# ---------- entry point -----------------------------------------------------
def rebalance(hotness, n_device: int, n_red_expert: int):
    """See module docstring for the algorithm summary."""
    hotness = np.asarray(hotness, dtype=np.float64)
    if hotness.ndim != 3:
        raise ValueError(
            f"hotness must be 3D (window, layers, experts), got {hotness.shape}"
        )
    n_layers = int(hotness.shape[1])
    n_experts = int(hotness.shape[2])
    n_dev = int(n_device)
    n_phys = n_experts + int(n_red_expert)
    exp_per_dev = n_phys // n_dev

    # Use the raw window sum as deepseek does. No smoothing, no clipping.
    weight = hotness.sum(axis=0)

    # Seed / refresh cur_deploy mirror if shape changed or first call.
    cur = _STATE.get("cur_deploy")
    if cur is None or cur.shape != (n_layers, n_dev, exp_per_dev):
        cur = _init_deploy(n_layers, n_dev, n_experts, n_phys)
        _STATE["cur_deploy"] = cur

    deploy_out = cur.copy()
    changed: list[int] = []
    # Process layers in order of total load: layers with heavier total load
    # tend to benefit most from rebalancing, so even with the simulator's
    # one-layer-per-iter redeploy queue we get the largest PAR drops sooner.
    layer_order = np.argsort(-weight.sum(axis=1))
    for L_np in layer_order:
        L = int(L_np)
        proposed = _propose_layer(weight[L], n_dev, n_phys)
        proposed = _anchor_to_prev(proposed, cur[L], n_experts)
        # Drop layers where anchoring eliminated every diff: nothing to send.
        if np.array_equal(proposed, cur[L]):
            continue
        deploy_out[L] = proposed
        cur[L] = proposed
        changed.append(L)

    if not changed:
        return False, np.array([], dtype=np.int64), deploy_out, None

    return True, np.array(changed, dtype=np.int64), deploy_out, None
